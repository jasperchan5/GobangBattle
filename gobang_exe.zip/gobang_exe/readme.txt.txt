1. 執行 main_s_local.exe
2. 等待管理員視窗跳出來，並等 main_s_local.exe 印出等待訊息
3. 執行「四個」main_c_local.exe
4. 等待四個玩家視窗跳出來
5. 開始遊玩